Here is the HTML and CSS code for the resume:

*HTML:*
<!DOCTYPE html>
<html>
<head>
	<title>Resume</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>RESUME</h1>
		<div class="contact-info">
			<p>SUBASREE V</p>
			<p>161/1 SCHOOL STREET AGRAPALAYAM</p>
			<p>THIRUVANNAMALAI 632314</p>
			<p>E-mail: subasreevelmurugan98@gmail.com</p>
			<p>Mobile No: 9751193369</p>
		</div>
		<div class="career-objective">
			<h2>CAREER OBJECTIVE</h2>
			<p>I am looking for an entry-level position to kick start my career and to work in a dynamic organization that will contribute to my professional and personal growth while I contribute to the growth of the company as well as engage opportunities to further the company's goals.</p>
		</div>
		<div class="educational-qualification">
			<h2>EDUCATIONAL QUALIFICATION</h2>
			<table>
				<tr>
					<th>Std</th>
					<th>School Name</th>
					<th>Board</th>
					<th>Percentage</th>
					<th>Year of passing</th>
				</tr>
				<tr>
					<td>10th</td>
					<td>Govt. Hr.Sec.School agrapalayam</td>
					<td>State Board</td>
					<td>82%</td>
					<td>2022</td>
				</tr>
				<tr>
					<td>12th</td>
					<td>Govt. Hr.Sec.School agrapalayam</td>
					<td>State Board</td>
					<td>73%</td>
					<td>2024</td>
				</tr>
				<tr>
					<td>B.Sc.(CS)</td>
					<td>SRI BHARATHI WOMENS ARTS AND SCIENCE COLLEGE KUNNATHUR</td>
					<td>Thiruvalluvar University</td>
					<td>89%</td>
					<td>2025</td>
				</tr>
				<tr>
			</table>
		</div>
		<div class="technical-skills">
			<h2>TECHNICAL SKILLS</h2>
			<ul>
				<li>Diploma in Computer Application</li>
				<li>Tally ERP 0.9</li>
			</ul>
		</div>
		<div class="skill-set">
			<h2>SKILL SET</h2>
			<ul>
				<li>Confident</li>
				<li>Good communication skills</li>
				<li>Good Interpersonal skill</li>
				<li>Practice</li>
			</ul>
		</div>
	</div>
</body>
</html>

CSS (in style.css file):
body {
	font-family: Arial, sans-serif;
	margin: 0;
	padding: 0;
}

.container {
	width: 80%;
	margin: 40px auto;
	padding: 20px;
	background-color: #f9f9f9;
	border: 1px solid #ddd;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
	text-align: center;
	margin-bottom: 20px;
}

.contact-info {
	margin-bottom: 20px;
}

.career-objective {
	margin-bottom: 20px;
}

.educational-qualification {
	margin-bottom: 20px;
}

table {
	width: 100%;
	border-collapse: collapse;
}

th, td {
	border: 1px solid #ddd;
	padding: 10px;
	text-align: left;
}

th {
	background-color: #f0f0f0;
}

.technical-skills {
	margin-bottom: 20px;
}

.skill-set {
	margin-bottom: 20px;
}

ul {
	list-style: none;
	padding: 0;
	margin: 0;
}

li {
	margin-bottom: 10px;
}

Note: You can adjust the styles as per your requirement. This is just a basic conversion of the resume into